import React, { useEffect, useState } from "react";

export default function FloatBar({ ed, onRun }) {
  const [vis, setVis] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0 });

  useEffect(() => {
    if (!ed) return;
    const fn = () => {
      const s = ed.state.selection;
      if (s && !s.empty) {
        setVis(true);
        const d = window.getSelection();
        if (d.rangeCount > 0) {
          const r = d.getRangeAt(0).getBoundingClientRect();
          setPos({ top: r.top - 40, left: r.left });
        }
      } else setVis(false);
    };
    ed.on("selectionUpdate", fn);
    window.addEventListener("scroll", fn);
    return () => {
      ed.off("selectionUpdate", fn);
      window.removeEventListener("scroll", fn);
    };
  }, [ed]);

  if (!vis) return null;
  return (
    <div
      style={{ position: "fixed", top: pos.top, left: pos.left }}
      className="bg-white shadow rounded p-2 z-50 flex gap-2"
    >
      <button
        className="px-2 py-1 text-sm border rounded"
        onClick={onRun}
      >
        Edit
      </button>
    </div>
  );
}
