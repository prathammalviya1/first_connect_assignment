import React from "react";
import Modal from "react-modal";
Modal.setAppElement("#__next");

export default function ModalBox({ view, onClose, onOk }) {
  const open = !!view;
  return (
    <Modal
      isOpen={open}
      onRequestClose={onClose}
      className="max-w-2xl mx-auto mt-20 bg-white p-6 rounded shadow"
    >
      <h2 className="text-lg font-semibold mb-3">Preview</h2>
      <div className="mb-4">
        <div className="p-2 border rounded bg-gray-50">{view?.org}</div>
      </div>
      <div className="mb-4">
        <div className="p-2 border rounded bg-white">{view?.sug}</div>
      </div>
      <div className="flex gap-2 justify-end">
        <button className="px-3 py-1 border rounded" onClick={onClose}>
          Cancel
        </button>
        <button
          className="px-3 py-1 bg-blue-600 text-white rounded"
          onClick={onOk}
        >
          Confirm
        </button>
      </div>
    </Modal>
  );
}
