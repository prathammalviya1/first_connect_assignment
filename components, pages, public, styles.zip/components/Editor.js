import React, { forwardRef, useImperativeHandle } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import FloatBar from "./FloatBar";

const EditorComp = forwardRef(({ onShow }, ref) => {
  const ed = useEditor({
    extensions: [StarterKit],
    content: `<h2>Welcome</h2><p>Select text and run AI edit.</p>`
  });

  useImperativeHandle(ref, () => ({
    replace(rng, txt) {
      if (!ed) return;
      ed.chain().focus().deleteRange(rng).insertContentAt(rng.from, txt).run();
    },
    insert(txt) {
      if (!ed) return;
      const pos = ed.state.selection.to;
      ed.chain().focus().insertContentAt(pos, txt).run();
    },
    pick() {
      if (!ed) return null;
      const s = ed.state.selection;
      const f = s.from, t = s.to;
      const val = ed.state.doc.textBetween(f, t, " ");
      return { from: f, to: t, text: val };
    }
  }));

  if (!ed) return null;

  return (
    <div className="relative">
      <FloatBar
        ed={ed}
        onRun={() => {
          const { from, to, text } = ref.current.pick();
          fetch("/api/ai-edit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ q: text, m: "edit" })
          })
            .then((r) => r.json())
            .then((d) => {
              onShow({ org: text, sug: d.sug, rng: { from, to } });
            });
        }}
      />
      <div className="prose border p-4 bg-white rounded">
        <EditorContent editor={ed} />
      </div>
    </div>
  );
});

export default EditorComp;
