import React, { useState } from "react";

export default function ChatSidebar({ edRef, onInsert }) {
  const [msgs, setMsgs] = useState([{ id: 1, who: "ai", txt: "Hello. Ask me to edit or summarize." }]);
  const [txt, setTxt] = useState("");

  const send = async () => {
    if (!txt.trim()) return;
    const u = { id: Date.now(), who: "u", txt };
    setMsgs((m) => [...m, u]);
    setTxt("");
    const r = await fetch("/api/ai-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ msg: txt })
    });
    const d = await r.json();
    if (d.type === "edit") {
      setMsgs((m) => [...m, { id: Date.now() + 1, who: "ai", txt: d.exp }]);
      onInsert(d.sug);
    } else {
      setMsgs((m) => [...m, { id: Date.now() + 1, who: "ai", txt: d.txt }]);
    }
  };

  return (
    <div className="p-4 h-screen flex flex-col">
      <div className="flex-1 overflow-auto mb-3">
        {msgs.map((m) => (
          <div
            key={m.id}
            className={`p-2 my-1 rounded ${m.who === "ai" ? "bg-gray-100 self-start" : "bg-blue-100 self-end"}`}
          >
            {m.txt}
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          value={txt}
          onChange={(e) => setTxt(e.target.value)}
          className="flex-1 border p-2 rounded"
        />
        <button onClick={send} className="px-3 py-2 bg-green-600 text-white rounded">
          Send
        </button>
      </div>
    </div>
  );
}
