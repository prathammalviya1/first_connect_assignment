import React, { useState, useRef } from "react";
import EditorBox from "../components/EditorBox";
import ChatBox from "../components/ChatBox";
import ModalBox from "../components/ModalBox";

export default function Home() {
  const [view, setView] = useState(null);
  const edRef = useRef();

  return (
    <div className="min-h-screen flex bg-gray-50">
      <main className="flex-1 p-6">
        <h1 className="text-xl mb-4">Live Editor Demo</h1>
        <EditorBox ref={edRef} onShow={setView} />
      </main>
      <aside className="w-96 border-l bg-white">
        <ChatBox
          edRef={edRef}
          onInsert={(t) => {
            edRef.current?.insert(t);
          }}
        />
      </aside>
      <ModalBox
        view={view}
        onClose={() => setView(null)}
        onOk={() => {
          if (!view) return;
          edRef.current?.replace(view.rng, view.sug);
          setView(null);
        }}
      />
    </div>
  );
}