import axios from "axios";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { msg } = req.body;
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(500).json({ err: "no key" });

  try {
    const r = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: msg }],
      max_tokens: 300
    }, { headers: { Authorization: `Bearer ${key}` } });

    const out = r.data.choices?.[0]?.message?.content || "no resp";
    res.json({ type: "reply", txt: out });
  } catch (e) {
    res.status(500).json({ err: "fail" });
  }
}
