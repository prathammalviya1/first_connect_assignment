import axios from "axios";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { q, m } = req.body;
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(500).json({ err: "no key" });

  let prompt = m === "shorten" ? `Make shorter:\n${q}` : m === "table" ? `Convert to table:\n${q}` : `Fix grammar and clarity:\n${q}`;

  try {
    const r = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2,
      max_tokens: 300
    }, { headers: { Authorization: `Bearer ${key}` } });

    res.json({ sug: r.data.choices?.[0]?.message?.content || "" });
  } catch (e) {
    res.status(500).json({ err: "fail" });
  }
}
